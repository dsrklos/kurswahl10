const italienischCheckbox = document.getElementById("italienischCheckbox");
const itafremdCheckbox = document.getElementById("itafremdCheckbox");
const regel1 = document.getElementById("regel1");


function updateRegel1Color() {
  if (!italienischCheckbox.checked && !itafremdCheckbox.checked) {
    regel1.style.color = "red";
    regel1.style.fontWeight = "bold";
  } 
  else if (italienischCheckbox.checked && itafremdCheckbox.checked) {
    regel1.style.color = "red";
    regel1.style.fontWeight = "bold";
  }
  else {
    regel1.style.color = "green";
    regel1.style.fontWeight = "bold";
  }
}

italienischCheckbox.addEventListener("change", updateRegel1Color);
itafremdCheckbox.addEventListener("change", updateRegel1Color);

updateRegel1Color();

/* Regel Fremdsprachen */

const englischCheckbox = document.getElementById("englischCheckbox");
const regel2 = document.getElementById("regel2");


function updateRegel2Color() {
  if (!italienischCheckbox.checked && !englischCheckbox.checked) {
    regel2.style.color = "red";
    regel2.style.fontWeight = "bold";
  } 
  else if (italienischCheckbox.checked && !englischCheckbox.checked) {
    regel2.style.color = "red";
    regel2.style.fontWeight = "bold";
  }
  else if (!italienischCheckbox.checked && englischCheckbox.checked) {
    regel2.style.color = "red";
    regel2.style.fontWeight = "bold";
  }
  else {
    regel2.style.color = "green";
    regel2.style.fontWeight = "bold";
  }
}

italienischCheckbox.addEventListener("change", updateRegel2Color);
englischCheckbox.addEventListener("change", updateRegel2Color);

updateRegel2Color();